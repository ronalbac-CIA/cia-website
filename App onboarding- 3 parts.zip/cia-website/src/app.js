// Main App Controller
const App = {
  route: 'dashboard',
  routeData: null,
  selectedPart: '1', // '1' or '2'

  // Protected routes — yêu cầu trial_active hoặc subscriber_active.
  isProtectedRoute(r) {
    if (!r) return false;
    return r === 'dashboard' || r === 'practice' || r === 'exam' || r === 'analytics'
        || r.startsWith('study-') || r.startsWith('lesson-');
  },

  init() {
    // Save Part 1 data reference before any swap
    window.CIA_DATA_P1 = window.CIA_DATA;
    Toast.init();
    if (typeof Lang !== 'undefined') Lang.apply();
    if (!Auth.isLoggedIn()) {
      this.renderAuthShell('landing');
    } else {
      if (sessionStorage.getItem('cia_part_picked') === '1') {
        // Restore selected part from session
        const savedPart = sessionStorage.getItem('cia_selected_part') || '1';
        this.switchPart(savedPart);
        this.buildShell();
        this.navigate('dashboard');
      } else {
        this.renderAuthShell('part-select');
      }
    }
    window.addEventListener('popstate', () => this.navigate(this.route));
  },

  // Switch the active data to the selected part
  switchPart(part) {
    this.selectedPart = part;
    sessionStorage.setItem('cia_selected_part', part);
    if (part === '3') {
      window.CIA_DATA = window.CIA_DATA_P3;
    } else if (part === '2') {
      window.CIA_DATA = window.CIA_DATA_P2;
    } else {
      window.CIA_DATA = window.CIA_DATA_P1;
    }
  },

  // Get the active data (convenience)
  getData() {
    return window.CIA_DATA;
  },

  getPartLabel() {
    return 'CIA Part ' + this.selectedPart;
  },

  getPartSubtitle() {
    if (this.selectedPart === '3') return 'Business Knowledge for Internal Auditing';
    if (this.selectedPart === '2') return 'Practice of Internal Auditing';
    return 'Essentials of Internal Auditing';
  },

  // Sau khi register/login thành công — vào part-select
  afterAuth() {
    this.renderAuthShell('part-select');
  },

  // Sau khi pick part → mark session và vào app
  afterPartPicked(part) {
    part = part || '1';
    this.switchPart(part);
    sessionStorage.setItem('cia_part_picked', '1');
    this.buildShell();
    this.navigate('dashboard');
  },

  // Render khi chưa login HOẶC chưa pick part
  renderAuthShell(initialRoute) {
    const appEl = document.querySelector('#app');
    appEl.classList.add('app-auth-mode');
    appEl.innerHTML = '<div id="auth-root"></div>';

    const renderAuth = (route) => {
      const root = document.querySelector('#auth-root');
      if (!root) return;
      root.innerHTML = '';
      root.scrollTop = 0;
      window.scrollTo(0, 0);

      if (route === 'register') {
        root.appendChild(RegisterPage.render(renderAuth));
      } else if (route === 'login') {
        root.appendChild(LoginPage.render(renderAuth));
      } else if (route === 'part-select') {
        if (!Auth.isLoggedIn()) { renderAuth('login'); return; }
        root.appendChild(PartSelectPage.render((next, data) => {
          if (next === 'dashboard') this.afterPartPicked(data?.part || '1');
          else renderAuth(next);
        }));
      } else if (route === 'dashboard') {
        this.afterPartPicked(this.selectedPart);
      } else {
        root.appendChild(LandingPage.render(renderAuth));
      }
    };
    renderAuth(initialRoute || 'landing');
  },

  logout() {
    if (!confirm('Sign out?')) return;
    Auth.logout();
    sessionStorage.removeItem('cia_part_picked');
    sessionStorage.removeItem('cia_selected_part');
    // Restore Part 1 as default
    this.switchPart('1');
    document.querySelector('#app').classList.remove('app-auth-mode');
    document.querySelector('#app').innerHTML = '';
    this.renderAuthShell('landing');
    Toast.success('Đã đăng xuất.');
  },

  goToPartSelect() {
    sessionStorage.removeItem('cia_part_picked');
    document.querySelector('#app').classList.remove('app-auth-mode');
    document.querySelector('#app').innerHTML = '';
    this.renderAuthShell('part-select');
  },

  buildShell() {
    const appEl = document.querySelector('#app');
    appEl.classList.remove('app-auth-mode');
    const partLabel = this.getPartLabel();
    appEl.innerHTML = `
      <!-- Topbar -->
      <div class="topbar">
        <div class="topbar-brand" id="brand-home">
          <div class="topbar-logo">CIA</div>
          <div>
            <div class="topbar-title">${partLabel}</div>
            <div class="topbar-subtitle">Study Prep</div>
          </div>
        </div>
        <div class="topbar-right">
          <div class="topbar-stats" id="topbar-stats"></div>
          <div class="topbar-account" id="topbar-account"></div>
        </div>
      </div>

      <!-- Sidebar -->
      <div class="sidebar" id="sidebar"></div>

      <!-- Main -->
      <div class="main-content" id="main-content"></div>
    `;

    document.querySelector('#brand-home').addEventListener('click', () => this.navigate('dashboard'));
    this.updateTopbarStats();
    this.updateTopbarAccount();
  },

  updateTopbarStats() {
    const stats = Storage.getStats();
    const el = document.querySelector('#topbar-stats');
    if (!el) return;
    el.innerHTML = `
      <div class="topbar-stat"><div class="topbar-stat-val">${stats.attempted}</div><div class="topbar-stat-lbl">Attempted</div></div>
      <div class="topbar-stat"><div class="topbar-stat-val">${stats.accuracy}%</div><div class="topbar-stat-lbl">Accuracy</div></div>
      <div class="topbar-stat"><div class="topbar-stat-val">${stats.bookmarks}</div><div class="topbar-stat-lbl">Saved</div></div>
    `;
  },

  updateTopbarAccount() {
    const el = document.querySelector('#topbar-account');
    if (!el) return;
    const user = Auth.currentUser();
    if (!user) { el.innerHTML = ''; return; }
    const status = Auth.getStatus(user);
    const rem = Auth.timeRemaining(user);

    let badgeText = '', badgeClass = 'badge-gray';
    if (status === 'trial_active') {
      badgeText = `Trial · ${rem.days}d ${rem.hours}h`;
      badgeClass = rem.days <= 2 ? 'badge-amber' : 'badge-blue';
    } else if (status === 'trial_expired') {
      badgeText = 'Trial expired';
      badgeClass = 'badge-red';
    } else if (status === 'subscriber_active') {
      badgeText = `Subscriber · ${rem.days}d`;
      badgeClass = 'badge-green';
    }

    el.innerHTML = `
      <div class="topbar-account-badge ${badgeClass}" id="acc-badge">${badgeText}</div>
      <div class="topbar-account-menu">
        <button class="topbar-account-btn" id="acc-btn">
          <span class="topbar-account-avatar">${user.username.charAt(0).toUpperCase()}</span>
          <span class="topbar-account-name">${user.username}</span>
          <span class="topbar-account-caret">▾</span>
        </button>
        <div class="topbar-account-dropdown hidden" id="acc-dropdown">
          <div class="topbar-account-dropdown-header">
            <div style="font-weight:700;color:var(--navy)">${user.username}</div>
            <div style="font-size:12px;color:var(--navy-600);margin-top:2px">
              ${status === 'subscriber_active' ? '⭐ Subscriber' : status === 'trial_active' ? '🎁 Free trial' : '⏰ Expired'}
            </div>
          </div>
          <div class="topbar-account-dropdown-item" data-action="part-select">📚 Switch CIA Part</div>
          <div class="topbar-account-dropdown-item" data-action="pricing">💳 Subscription &amp; Pricing</div>
          <div class="topbar-account-dropdown-item" data-action="analytics">📊 My Progress</div>
          <div class="topbar-account-dropdown-divider"></div>
          <div class="topbar-account-dropdown-item topbar-account-logout" data-action="logout">↪ Đăng xuất</div>
        </div>
      </div>
    `;

    const dropdown = el.querySelector('#acc-dropdown');
    el.querySelector('#acc-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('hidden');
    });
    document.addEventListener('click', () => dropdown.classList.add('hidden'));
    el.querySelectorAll('[data-action]').forEach(item => {
      item.addEventListener('click', () => {
        const a = item.dataset.action;
        dropdown.classList.add('hidden');
        if (a === 'logout') this.logout();
        else if (a === 'part-select') this.goToPartSelect();
        else this.navigate(a);
      });
    });

    el.querySelector('#acc-badge')?.addEventListener('click', () => this.navigate('pricing'));
  },

  navigate(route, data = null) {
    if (!Auth.isLoggedIn()) { this.renderAuthShell('login'); return; }
    if (this.isProtectedRoute(route) && !Auth.hasAccess()) {
      route = 'pricing';
      data = { reason: 'trial_expired' };
      if (Auth.getStatus() === 'trial_expired') {
        Toast.error('Your 7-day free trial has expired. Please subscribe to continue learning.');
      }
    }

    this.route = route;
    this.routeData = data;

    const sidebar = document.querySelector('#sidebar');
    if (sidebar) Sidebar.mount(sidebar, route, (r, d) => this.navigate(r, d));

    const main = document.querySelector('#main-content');
    if (!main) return;
    main.innerHTML = '';

    const nav = (r, d) => this.navigate(r, d);

    if (route === 'dashboard') {
      main.appendChild(DashboardPage.render(nav));
    } else if (route === 'pricing') {
      main.appendChild(PricingPage.render(nav, data || {}));
    } else if (route.startsWith('study-')) {
      const suId = route.split('-')[1];
      StudyUnitPage.activeTab = 'learn';
      main.appendChild(StudyUnitPage.render(suId, nav));
    } else if (route.startsWith('lesson-')) {
      const subId = route.split('lesson-')[1];
      const suId = subId.split('.')[0];
      StudyUnitPage.activeSubunit = null;
      const su = window.CIA_DATA.studyUnits.find(s => s.id === suId);
      const sub = su?.subunits.find(s => s.id === subId);
      if (su && sub) {
        StudyUnitPage.activeSubunit = sub;
        main.appendChild(StudyUnitPage.render(suId, nav));
      }
    } else if (route === 'practice') {
      const opts = this.routeData || {};
      main.appendChild(PracticePage.render(nav, opts));
    } else if (route === 'exam') {
      main.appendChild(ExamPage.render(nav));
    } else if (route === 'analytics') {
      main.appendChild(AnalyticsPage.render(nav));
    }

    this.updateTopbarStats();
    this.updateTopbarAccount();
    main.scrollTop = 0;
  }
};

// Boot
document.addEventListener('DOMContentLoaded', () => App.init());
