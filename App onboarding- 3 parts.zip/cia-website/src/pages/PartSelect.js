// Part Selection page — chọn CIA Part sau khi login.
// Part 1 & Part 2 active; Part 3 coming soon.
const PartSelectPage = {
  render(onNavigate) {
    const user = Auth.currentUser();
    const container = document.createElement('div');
    container.className = 'part-select';

    // Get stats for each part
    const p1Data = window.CIA_DATA_P1;
    const p2Data = window.CIA_DATA_P2;
    const p3Data = window.CIA_DATA_P3;

    container.innerHTML = `
      <div class="part-select-inner">
        <div class="part-select-head">
          <div class="part-select-eyebrow">Welcome back</div>
          <h1 class="part-select-title">Hi ${user?.username || ''}, which CIA Part are you preparing for?</h1>
          <p class="part-select-sub">Choose a part to start studying. You can switch anytime from the top bar.</p>
        </div>

        <div class="part-grid">
          <!-- PART 1 -->
          <div class="part-card part-card-active" data-part="1">
            <div class="part-card-glow"></div>
            <div class="part-card-top">
              <div class="part-card-num">CIA Part 1</div>
              <div class="part-card-status part-status-available">● Available</div>
            </div>
            <div class="part-card-icon">🏛️</div>
            <h2 class="part-card-name">Essentials of Internal Auditing</h2>
            <p class="part-card-desc">Foundations, independence, governance, risk management, controls, fraud, and engagement planning.</p>
            <div class="part-card-meta">
              <div class="pcm-item"><div class="pcm-v">${p1Data.meta.totalStudyUnits}</div><div class="pcm-l">Study Units</div></div>
              <div class="pcm-item"><div class="pcm-v">${p1Data.meta.totalQuestions.toLocaleString()}</div><div class="pcm-l">Questions</div></div>
              <div class="pcm-item"><div class="pcm-v">150 min</div><div class="pcm-l">Exam mode</div></div>
            </div>
            <div class="part-card-features">
              <div class="pcf-item"><span class="pcf-check">✓</span> Full access to all Study Units</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Practice question bank with explanations</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Realistic exam mode simulation</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Personal progress &amp; analytics</div>
            </div>
            <button class="btn btn-primary btn-lg w-full" id="enter-p1">
              Start Part 1 <span>→</span>
            </button>
          </div>

          <!-- PART 2 -->
          <div class="part-card part-card-active" data-part="2">
            <div class="part-card-glow"></div>
            <div class="part-card-top">
              <div class="part-card-num">CIA Part 2</div>
              <div class="part-card-status part-status-available">● Available</div>
            </div>
            <div class="part-card-icon">🛡️</div>
            <h2 class="part-card-name">Practice of Internal Auditing</h2>
            <p class="part-card-desc">Business acumen, IT &amp; cybersecurity, engagement planning, execution, analysis, documentation, and communications.</p>
            <div class="part-card-meta">
              <div class="pcm-item"><div class="pcm-v">${p2Data.meta.totalStudyUnits}</div><div class="pcm-l">Study Units</div></div>
              <div class="pcm-item"><div class="pcm-v">${p2Data.meta.totalQuestions.toLocaleString()}</div><div class="pcm-l">Questions</div></div>
              <div class="pcm-item"><div class="pcm-v">150 min</div><div class="pcm-l">Exam mode</div></div>
            </div>
            <div class="part-card-features">
              <div class="pcf-item"><span class="pcf-check">✓</span> 14 Study Units with lessons</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> 1,981 practice questions with explanations</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Exam mode simulation</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Personal progress &amp; analytics</div>
            </div>
            <button class="btn btn-primary btn-lg w-full" id="enter-p2">
              Start Part 2 <span>→</span>
            </button>
          </div>

          <!-- PART 3 -->
          <div class="part-card part-card-active" data-part="3">
            <div class="part-card-glow"></div>
            <div class="part-card-top">
              <div class="part-card-num">CIA Part 3</div>
              <div class="part-card-status part-status-available">● Available</div>
            </div>
            <div class="part-card-icon">💼</div>
            <h2 class="part-card-name">Business Knowledge for Internal Auditing</h2>
            <p class="part-card-desc">Internal audit operations, strategy &amp; communication, risk-based audit plan, quality assurance, and engagement results &amp; monitoring.</p>
            <div class="part-card-meta">
              <div class="pcm-item"><div class="pcm-v">${p3Data.meta.totalStudyUnits}</div><div class="pcm-l">Study Units</div></div>
              <div class="pcm-item"><div class="pcm-v">${p3Data.meta.totalQuestions.toLocaleString()}</div><div class="pcm-l">Questions</div></div>
              <div class="pcm-item"><div class="pcm-v">120 min</div><div class="pcm-l">Exam mode</div></div>
            </div>
            <div class="part-card-features">
              <div class="pcf-item"><span class="pcf-check">✓</span> 6 Study Units with lessons</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> 752 practice questions with explanations</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Exam mode simulation</div>
              <div class="pcf-item"><span class="pcf-check">✓</span> Personal progress &amp; analytics</div>
            </div>
            <button class="btn btn-primary btn-lg w-full" id="enter-p3">
              Start Part 3 <span>→</span>
            </button>
          </div>
        </div>

        <div class="part-select-footer">
          <button class="part-select-logout" id="ps-logout">↪ Sign out</button>
        </div>
      </div>
    `;

    container.querySelector('#enter-p1').addEventListener('click', () => onNavigate('dashboard', { part: '1' }));
    container.querySelector('#enter-p2').addEventListener('click', () => onNavigate('dashboard', { part: '2' }));
    container.querySelector('#enter-p3').addEventListener('click', () => onNavigate('dashboard', { part: '3' }));
    
    // Click anywhere on the active cards
    container.querySelectorAll('.part-card-active').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON') return;
        const part = card.dataset.part;
        onNavigate('dashboard', { part });
      });
    });

    container.querySelectorAll('.part-card-locked').forEach(card => {
      card.addEventListener('click', () => {
        Toast.show('That part is not available yet — focus on Part 1 or Part 2 for now! 🎯', 'info');
      });
    });
    container.querySelector('#ps-logout').addEventListener('click', () => App.logout());

    return container;
  }
};
